---
name: policy-lookup
description: Answer HR policy questions from the handbook this set ships with.
---

# Policy lookup

Use this skill when someone asks what a company HR policy says.

1. Read `references/handbook.md` from this skill's directory.
2. Quote the relevant clause verbatim, then summarise it in one sentence.
3. If the handbook does not cover the question, say so — do not infer a policy.
