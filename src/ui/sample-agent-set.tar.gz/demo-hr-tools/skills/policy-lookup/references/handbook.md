# Demo HR handbook (excerpt)

## Annual leave
Full-time employees accrue 1.75 days of paid leave per completed month.

## Remote work
Up to three days per week, agreed with the reporting manager in advance.
