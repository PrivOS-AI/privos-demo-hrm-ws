---
description: Report an employee's remaining leave balance.
argument-hint: <employee name>
---

Look up $ARGUMENTS in the HR records list, subtract the leave already taken this
year from their accrual, and report the remaining balance in days.
